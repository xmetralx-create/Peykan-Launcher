package ir.peykanlauncherfa

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("peykanlauncher", MODE_PRIVATE) }
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var savedText: TextView
    private val bg = Color.rgb(16, 24, 20)
    private val panel = Color.rgb(29, 42, 34)
    private val green = Color.rgb(90, 190, 110)
    private val white = Color.rgb(240, 245, 240)
    private val muted = Color.rgb(175, 190, 178)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        scroll.addView(content)

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.peykan_launcher_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "لوگوی پیکان لانچر"
        }
        content.addView(logo, LinearLayout.LayoutParams(-1, dp(210)))
        content.addView(text("Peykan Launcher", 30f, green, true))
        content.addView(text("لانچر ساده ماینکرفت جاوا برای اندروید", 15f, muted).apply { setPadding(0, dp(4), 0, dp(22)) })

        val playCard = card()
        playCard.addView(text("آماده‌ای بازی کنی؟", 20f, white, true))
        playCard.addView(text("برای اجرای بازی، لانچر Amethyst باید نصب باشد.", 14f, muted).apply { setPadding(0, dp(8), 0, dp(14)) })
        playCard.addView(button("اجرای Minecraft Java", green) { openAmethyst() })
        content.addView(playCard)

        content.addView(text("افزودن سرور", 21f, white, true).apply { setPadding(0, dp(22), 0, dp(10)) })
        val serverCard = card()
        hostInput = edit("آدرس سرور (مثلاً play.example.net)")
        portInput = edit("پورت (معمولاً 25565)").apply { setText("25565"); inputType = 2 }
        serverCard.addView(hostInput)
        serverCard.addView(space(8))
        serverCard.addView(portInput)
        serverCard.addView(space(12))
        serverCard.addView(button("ذخیره سرور", green) { saveServer() })
        content.addView(serverCard)

        content.addView(text("سرور ذخیره‌شده", 20f, white, true).apply { setPadding(0, dp(22), 0, dp(10)) })
        val savedCard = card()
        savedText = text("هنوز سروری ذخیره نکرده‌ای.", 14f, muted)
        savedCard.addView(savedText)
        content.addView(savedCard)

        content.addView(text("راهنما", 20f, white, true).apply { setPadding(0, dp(22), 0, dp(8)) })
        content.addView(text("۱) Amethyst را نصب و با حساب مایکروسافت خود وارد شو.\n۲) نسخه سازگار Minecraft را نصب کن.\n۳) بازی را اجرا کن و از بخش Multiplayer سرور را اضافه کن.\n\nاین برنامه فعلاً آدرس سرور را نگه می‌دارد؛ اتصال مستقیم از داخل Peykan Launcher در نسخه بعدی اضافه می‌شود.", 14f, muted))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshSaved()
    }

    private fun openAmethyst() {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = packageManager.queryIntentActivities(launcherIntent, 0)
        val target = matches.firstOrNull {
            packageManager.getApplicationLabel(it.activityInfo.applicationInfo).toString().contains("amethyst", true)
        }
        if (target != null) {
            val launch = packageManager.getLaunchIntentForPackage(target.activityInfo.packageName)
            if (launch != null) { startActivity(launch); return }
        }
        AlertDialogBuilder.show(this, "Amethyst پیدا نشد", "ابتدا لانچر Amethyst را از منبع رسمی نصب کن؛ سپس دوباره این دکمه را بزن.")
    }

    private fun saveServer() {
        val host = hostInput.text.toString().trim()
        val port = portInput.text.toString().trim().ifBlank { "25565" }
        if (host.isBlank()) { hostInput.error = "آدرس سرور را وارد کن"; return }
        prefs.edit().putString("host", host).putString("port", port).apply()
        refreshSaved()
        Toast.makeText(this, "سرور ذخیره شد", Toast.LENGTH_SHORT).show()
    }

    private fun refreshSaved() {
        val host = prefs.getString("host", null)
        val port = prefs.getString("port", "25565")
        savedText.text = if (host == null) "هنوز سروری ذخیره نکرده‌ای." else "$host:$port\nبرای اتصال، این آدرس را در بخش Multiplayer بازی وارد کن."
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(18).toFloat() }
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.RIGHT
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
    }
    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 15f; setTextColor(white); setHintTextColor(muted)
        setSingleLine(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(40,55,45)); cornerRadius = dp(10).toFloat() }
        layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
    }
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; setTextColor(Color.rgb(10,25,14)); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        setOnClickListener { action() }
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

private object AlertDialogBuilder {
    fun show(activity: Activity, title: String, message: String) {
        android.app.AlertDialog.Builder(activity).setTitle(title).setMessage(message).setPositiveButton("متوجه شدم", null).show()
    }
}
